---
name: prd-to-qmetry-testcases
description: Generate non-executable QMetry test cases from PRD user stories in i2o-project-ai-docs. Use when asked to read `prd.md`, derive manual QA test cases, run user review, and push approved cases to QMetry for a specific module/project/release.
---

# PRD To QMetry Testcases

## Goal
Generate high-quality manual (non-executable) test cases from PRD user stories and push them to QMetry only after explicit user approval.

## Inputs
Collect and confirm these inputs before execution:
- `module` (required): expected branch name such as `price_monitoring`, `growth_accelerator`, `brand_protection`
- `project_name` (required): project directory under `projects/`
- `release_version` (required): release folder, default `7.5` when user does not provide one

QMetry target project id is static and must always be `10537`.

## Preflight
1. Verify required tools: `git`, `python3`, and Markdown parsing capability.
2. Verify QMetry credentials from repository-local file `.jira/credentials.json`:
   - Required fields:
     - `apiKey`
     - `basicAuthBase64` (base64 token only, without `Basic ` prefix)
   - Required fixed field:
     - `project_id` must be `10537`
   - Optional field:
     - `base_url` (default `https://qtmcloud.qmetry.com`; use `https://syd-qtmcloud.qmetry.com` for AU)
3. If `.jira/credentials.json` is missing or incomplete, ask the user once for `apiKey` and `basicAuthBase64`, then create/update `.jira/credentials.json` and reuse it in future runs.
4. Validate credentials with a safe GET call before push:
   ```bash
   curl --request GET \
     --url https://qtmcloud.qmetry.com/rest/api/latest/projects/10537/priorities \
     --header 'apikey: <apiKey>' \
     --header 'authorization: Basic <base64encoded_string>' \
     --header 'content-type: application/json'
   ```
5. Ask concise clarification questions when requirements are ambiguous.
6. Do not push anything to QMetry before explicit user confirmation.

Use [scripts/prd_preflight.py](scripts/prd_preflight.py) for deterministic repository/branch/PRD checks.

## Credentials File Contract
Store credentials at `.jira/credentials.json` (repository root):

```json
{
  "project_id": 10537,
  "apiKey": "<qmetry_api_key>",
  "basicAuthBase64": "<jira_email_colon_api_token_base64>",
  "base_url": "https://qtmcloud.qmetry.com"
}
```

Rules:
- Create `.jira/` if it does not exist.
- Reuse existing credentials on subsequent runs.
- Never print secrets in logs or reports.
- Do not commit `.jira/credentials.json`.

## Workflow

### 1) Clone Docs Repository
1. Clone repository when absent:
   ```bash
   git clone https://github.com/sandeep-i2o/i2o-project-ai-docs/
   ```
2. Reuse existing local clone when present.

### 2) Resolve Branch from Module
1. Treat `module` as branch name.
2. Check whether branch exists in origin.
3. If branch does not exist, stop and ask user for the correct branch name.
4. Checkout resolved branch.

### 3) Locate PRD
Read this path exactly:
`projects/{project_name}/{release_version}/docs/requirements/prd.md`

If file is missing, stop and report the exact missing path.

### 4) Generate Test Cases from PRD
1. Parse all user stories in `prd.md`.
2. If no user stories exist, stop with an error: `User stories are not present in the document.`
3. Read edge cases and corner cases from PRD and include coverage.
4. Consult product guides from `knowledge/kb_pdfs/` for domain-specific behavior and terminology.
5. Generate only manual/non-executable test cases compatible with QMetry import/API.
6. Save generated cases to JSON for push step, e.g.:
   `artifacts/qmetry_testcases_{module}_{release_version}.json`

Use QMetry structure from [references/qmetry-testcase-format.md](references/qmetry-testcase-format.md).

### 5) Review Gate (Mandatory)
1. Present generated test cases to the user in a reviewable table/list.
2. Ask for explicit approval and requested edits.
3. Apply requested edits and re-present when needed.
4. Update the JSON artifact so it exactly matches the approved version.

### 6) Push Gate (Mandatory)
1. Push to QMetry only after explicit confirmation such as `Approved`, `Proceed`, or equivalent clear consent.
2. If approval is not explicit, do not push.
3. Run API push script with fixed project id `10537`:
   ```bash
   python3 scripts/qmetry_push_testcases.py \
     --input artifacts/qmetry_testcases_{module}_{release_version}.json \
     --project-id 10537 \
     --module {module} \
     --release {release_version}
   ```
4. Ensure script runtime uses `apiKey` and `basicAuthBase64` from `.jira/credentials.json`.
5. Use `--dry-run` first when requested to validate payload without creating test cases.

### 7) Report Push Result
After push, report:
1. Created test case keys/IDs.
2. Any warnings (for example, unmapped labels).
3. Concise coverage summary by user story and priority.

## QMetry API Contract
- Base path: `/rest/api/latest`
- Create endpoint: `POST /rest/api/latest/testcases`
- Fixed project id: `10537`
- Required headers:
  - `authorization: Basic <basicAuthBase64>`
  - `apikey: <apiKey>`
- Script lookups used for safe mapping:
  - `GET /rest/api/latest/projects/10537/priorities`
  - `GET /rest/api/latest/projects/10537/testcase-statuses`
  - `GET /rest/api/latest/projects/10537/labels`

## QMetry Compatibility Rules
- Set case type to manual/non-executable (`isAutomated=false`).
- Keep each test case atomic with clear preconditions, steps, and expected results.
- Map each test case to at least one user story identifier or title.
- Include priority and module labels where available.
- Include release version metadata (label and/or description metadata).

## Output Contract
Produce both:
1. Human-review markdown table/list.
2. QMetry push JSON artifact (input for `scripts/qmetry_push_testcases.py`).

## Failure Conditions
Stop and report clearly when any condition is met:
- branch missing for provided module
- `prd.md` missing at required path
- user stories absent in PRD
- `.jira/credentials.json` missing/unreadable and user did not provide required credentials
- QMetry API rejects payload/auth

## Guardrails
- Do not invent user stories.
- Do not skip edge cases documented in PRD.
- Do not push unreviewed test cases.
- Never expose `apiKey` or `basicAuthBase64` in output.
- Keep communication concise and ask questions when ambiguity blocks accurate test design.
